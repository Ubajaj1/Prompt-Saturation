Supplementary Material: Prompt Saturation
==========================================

This archive contains the code, data, and results for the paper
"Prompt Saturation: Quality Plateaus at Task-Specific Token Thresholds
in Large Language Models."

Structure:
  greenprompt/       - Core library (evaluators, LLM providers)
  experiments/       - Benchmark runner, analysis scripts, prompt templates
  results/           - Raw results (JSON), summary statistics, figures
  scripts/           - Utility scripts (SQuAD extraction)

Key files:
  experiments/saturation_prompts.py    - 7-level additive prompt templates (6 tasks)
  experiments/saturation_benchmark.py  - Benchmark runner with LLM judge evaluation
  experiments/saturation_analysis.py   - Curve fitting, F-tests, bootstrap CIs
  results/saturation_results_judge.json       - 5,875 LLM-judge-scored records (4 original tasks)
  results/saturation_results_new_tasks.json   - 1,955 records (2 additional tasks)

Replication experiment (Section 4.5):
  replication_experiment.py            - Standalone runner for 200-example replication
  replication_analysis.py              - Analysis script for replication results
  scripts/extract_squad_qa.py          - SQuAD Q/A pair extraction utility
  results/replication/                 - Replication figures (classification + QA)

To reproduce the main experiment:
  1. pip install openai google-generativeai groq anthropic tiktoken scipy numpy pandas matplotlib
  2. Set API keys: OPENAI_API_KEY, GEMINI_API_KEY, GROQ_API_KEY, ANTHROPIC_API_KEY
  3. Run benchmark: python experiments/saturation_benchmark.py --evaluator llm_judge
  4. Run analysis:  python experiments/saturation_analysis.py

To reproduce the replication experiment (Section 4.5):
  1. Download SST-2 dev set and SQuAD v1.1 dev set into replication-data/
  2. python replication_experiment.py --examples 200 --evaluator llm_judge
  3. python replication_analysis.py
